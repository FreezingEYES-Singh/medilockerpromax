<?php include "header.php"; ?>
    <div id="adiv">
        <h1>About Medilocker</h1>
        <br>
        <p>1.This is a website created to keep safe your uploads</p>
        <br>
        <p>2.You can see and download them anywhere in the world</p>
        <br>
        <br>
        <h1>How to Submit??</h1>
        <br>
        <p>1.Click on upload button.</p>
        <br>
        <p>2.Then click on "Choose File" button and choose your file</p>
        <br>
        <p>3.After choosing file, enter the name of the file like Adhar Card,Pen Card etc</p>
        <br>
        <p>4.Then click on Submit</p>
    </div>

        
<?php include "footer.php"; ?>