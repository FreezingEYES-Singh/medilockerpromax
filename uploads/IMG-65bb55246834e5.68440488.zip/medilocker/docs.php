<?php include "header.php";?>

<div class="everything2">
    <div class="et2">
        <?php $b =  "SELECT * FROM images ORDER BY id DESC";
        $res2 =  mysqli_query($conn, $b);
        foreach($res2 as $z){
            if ($z['username'] == $row['name']){?>
                 <div>
                    <span>
                        <img src="uploads/<?=$z['image_url']?>" class="dimg">
                        <br>
                        <h3 id="imgn"><?php echo $z['imagenames'];?></h3> 
                        <br>
                        <a href="uploads/<?=$z['image_url']?>" class="link1">View</a>&nbsp;&nbsp;&nbsp;&nbsp;
                        <a href="uploads/<?=$z['image_url']?>" Download class="link1">Download</a>
                       
                
                    </span>
                </div>
            <?php
        
            
     }}  
?>
    </div>


</div>
<script src="app2.js"></script>
<?php include "footer.php"; ?>
