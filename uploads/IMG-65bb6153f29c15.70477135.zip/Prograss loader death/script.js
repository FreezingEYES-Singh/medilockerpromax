// =-----------------------------
const fileuploader = document.getElementById("file-uploader");
      const death = document.getElementById("death-group");
      const progress = document.getElementById("progress-time-fill");
      const arm = document.getElementById("designer-arm-grop");
      const rf = document.getElementById("red-flame");
      const yf = document.getElementById("yellow-flame");
      const wf = document.getElementById("white-flame");

      const reader = new FileReader();

      const days = document.getElementById("ddays");

      progress.style.x = "200%";

      fileuploader.addEventListener("change", (event) => {
        const files = event.target.files;
        const file = files[0];
        reader.readAsDataURL(file);

        reader.addEventListener("progress", (event) => {
          if (event.loaded && event.total) {
            let percent = (event.loaded / event.total) * 100;
            progress.style.x = percent - 100 + "%";
            days.innerHTML = Math.round(percent) + "%";
            death.style.cssText =
              "transform: translateX(" + percent * 5.2 + "px);";

            if (percent <= 20) {
              arm.style.animationDuration = "2s";
              rf.style.cssText = yf.style.cssText = wf.style.cssText = "opacity:0;" ;
            } else if (percent <= 40) {
              rf.style.cssText = yf.style.cssText = wf.style.cssText = "opacity:0;" ;
              arm.style.animationDuration = "1.7s";
            } else if (percent <= 60) {
              rf.style.cssText = yf.style.cssText = wf.style.cssText = "opacity:0;" ;
              arm.style.animationDuration = "1.3s";
            } else if (percent <= 80) {
              rf.style.cssText = yf.style.cssText = wf.style.cssText = "opacity:0.7;" ;
              arm.style.animationDuration = "1s";
            } else if (percent <= 100) {
              rf.style.cssText = yf.style.cssText = wf.style.cssText = "opacity:1;" ;
              arm.style.animationDuration = "0.75s";
            }

            if (percent === 100) {
              let msg =
                "<span> File <u><br> " +
                file.name +
                "</b> <u> has been uploaded successfully.</span>";
              lfeedback.innerHTML = msg;
            }
          }
        });
      });
// =------------------------------

// Init
// var $ = jQuery;
// var animationTime = 20,
//     days = 7;
 
// $(document).ready(function(){

    // timer arguments: 
    //   #1 - time of animation in mileseconds, 
    //   #2 - days to deadline

//     var deadlineAnimation = function () {

//             $('#designer-arm-grop').css({'animation-duration': percent+'s'});
//         };

//     function timer(totalTime, deadline) {
//         var time = totalTime * 1000;
//         var dayDuration = time / deadline;
//         var actualDay = deadline;

//         var timer = setInterval(countTime, dayDuration);

//         function countTime() {
//             --actualDay;
//             $('.deadline-days .day').text(actualDay);

//             if (actualDay == 0) {
//                 clearInterval(timer);
//                 $('.deadline-days .day').text(deadline);
//             }
//         }
//     }

//     var deadlineText = function () {
//         var $el = $('.deadline-days');
//         var html = '<div class="mask-red"><div class="inner">' + $el.html() + '</div></div><div class="mask-white"><div class="inner">' + $el.html() + '</div></div>';
//         $el.html(html);
//     }

//     deadlineText();

//     deadlineAnimation();
//     timer(animationTime, days);

//     setInterval(function(){
//         timer(animationTime, days);
//         deadlineAnimation();

//         console.log('begin interval', animationTime * 1000);

//     }, animationTime * 1000);

// });